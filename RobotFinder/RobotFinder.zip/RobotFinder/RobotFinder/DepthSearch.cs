﻿using System;
namespace RobotFinder
{
	public class DepthSearch
	{
		
		public DepthSearch()
		{
		}
	}
}
